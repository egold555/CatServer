package net.minecraft.block;

public class BlockRedFlower extends BlockFlower
{
    public EnumFlowerColor getBlockType()
    {
        return EnumFlowerColor.RED;
    }
}