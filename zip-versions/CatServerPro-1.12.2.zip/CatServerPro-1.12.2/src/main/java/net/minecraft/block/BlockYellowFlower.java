package net.minecraft.block;

public class BlockYellowFlower extends BlockFlower
{
    public EnumFlowerColor getBlockType()
    {
        return EnumFlowerColor.YELLOW;
    }
}